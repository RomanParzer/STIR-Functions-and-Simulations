README for R Code STIR Simulations

There are 4 folders:
- simulations
- results
- Rmkd
- functions

In 'simulations' there are the R scripts performing the simulations and saving it
(into 'results' folder) in a .rds object containing all relevant results.
Each of these files has the following structure:
- read in needed functions
- define function for data generation
- define function for performing simulations
- define list of parameter settings
- for each parameter setting perform simulation and save results
These files should be run from this folder (set the PATH).

In 'Rmkd' there are .rmd files reading in the results (.rds files) and creating the Tables.

The functions folder includes R source code for used own functions, i.e. STIR() (with either polynomial or Fourier basis for time), and (in STIR_flexible_time.R) a version, where the user can supply the S matrix. The LSIR() function in lsir_adapted.R is an adapted version from 
(R.  M.  Pfeiffer,  D.  B.  Kapla,  and  E.  Bura.   Least  squares  and  maximum  likelihoode stimation of sufficient reductions in regressions with matrix-valued predictors.International Journal of Data Science and Analytics, pages 1–16, 2020), also the other two functions were provided by D. Kapla.
